package com.zenika.zencontact.domain;

public class Message {
    public String message;
}
